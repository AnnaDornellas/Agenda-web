<?php
namespace App\Model;
use System\Classes\Model;

class ErrorModel extends Model {

    public function __construct() {
        parent::__construct();
    }

    public function index() {
        
    }

    public function add() {
        
    }

    public function edit() {
        
    }

    public function delete() {
       
    }

}

# tinymvc-clear

Para rodar o SASS corretamente no Theme Default www/

Use:

sass --watch scss/custom.scss:css/custom.css --style compressed


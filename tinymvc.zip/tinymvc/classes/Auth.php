<?php

namespace System\Classes;
use System\Classes\Model;
use System\Classes\Controller;

class Auth {

    private $authLogged = null;
    private $authTable = null;
    private $authFieldUsername = null;
    private $authFieldPassword = null;
    private $authLogoutRedirectNickname = null;
    private $authMessageLogout = null;
    private $authMessageAccessDenied = null;
    private $message = null;

    public function set($params) {

        $this->setAuthTable(authTable);
        $this->setAuthFieldUsername(authFieldUsername);
        $this->setAuthFieldPassword(authFieldPassword);
        $this->setAuthLogoutRedirectNickname(authLogoutRedirectNickname);
        $this->setAuthMessageLogout(authMessageLogout);
        $this->setAuthMessageAccessDenied(authMessageAccessDenied);

        $args[authFieldUsername] = $params[authFieldUsername];
        $args[authFieldPassword] = $params[authFieldPassword];

        $this->existsUser($args);
        $this->user();
    }

    private function setToken($token) {
        $this->token = $token;
    }

    private function setAuthTable($table_name) {
        $this->authTable = $table_name;
    }

    private function setAuthMessageLogout($message_logout) {
        $this->authMessageLogout = $message_logout;
    }

    private function setAuthLogoutRedirectNickname($redirect_nickname) {
        $this->authLogoutRedirectNickname = $redirect_nickname;
    }

    private function setAuthMessageAccessDenied($access_denied) {
        $this->authMessageAccessDenied = $access_denied;
    }

    private function setAuthFieldUsername($field_username) {
        $this->authFieldUsername = $field_username;
    }

    private function setAuthFieldPassword($field_password) {
        $this->authFieldPassword = $field_password;
    }

    private function setLogged($Logged) {
        $this->authLogged = $Logged;
    }

    private function setMessage($message) {
        $this->message = $message;
    }

    private function getAuthMessageLogout() {
        return $this->authMessageLogout;
    }

    private function getAuthLogoutRedirectNickname() {
        return $this->authLogoutRedirectNickname;
    }

    private function getAuthMessageAccessDenied() {
        return $this->authMessageAccessDenied;
    }

    private function getAuthTable() {
        return $this->authTable;
    }

    private function getAuthFieldUsername() {
        return $this->authFieldUsername;
    }

    private function getAuthFieldPassword() {
        return $this->authFieldPassword;
    }

    public function getMessage() {
        return $this->message;
    }

    private function existsUser($args) {

        $users = Model::drive($this->getAuthTable());
        $params[$this->getAuthFieldUsername()] = $args[$this->getAuthFieldUsername()];
        $params["registration"] = $args[$this->getAuthFieldUsername()];
        $logical_operator = ['='];
        $users->select('*')->conditions($params, $logical_operator, "OR")->execute();

        $row = $users->get();

        if (isset($row[0])) {

            $user = $row[0];
            if ($user["status"]) {
                $Controller = new Controller();
                if ($Controller->verifyPassword($args[$this->getAuthFieldPassword()], $user[$this->getAuthFieldPassword()])) {
                    foreach ($user as $name => $value) {
                        $_SESSION[$name] = $value;
                    }
                    $this->setLogged(true);
                    $this->setMessage("Olá {$user['name']}, seja bem-vindo(a)!");
                } else {
                    $this->setMessage("Por favor, verifique a sua senha e tente novamente!");
                }
            } else {
                $this->setMessage("Usuário desativado, entre em contato com o administrador!");
            }
        } else {
            $this->setMessage("Usuário não encontrado");
        }
    }

    public function logged() {

        if (isset($_SESSION[authFieldUsername]) && isset($_SESSION[authFieldPassword])) {
            $this->setLogged(true);
        } else {
            $this->setLogged(false);
        }
        return $this->authLogged;
    }

    public function user() {
        $user = null;
        if (isset($_SESSION[authFieldUsername]) && isset($_SESSION[authFieldPassword])) {
            return (object) $_SESSION;
        }
        return $user;
    }
    
    public function allows($allow_type) {
        if (isset($_SESSION[authFieldUsername]) && isset($_SESSION[authFieldPassword])) {
            $allows = explode(",", $_SESSION["allow"]);
            if(in_array($allow_type, $allows)){
                return true;
            } else {
                return false;
            }
        }
    }

    public function die() {

        session_destroy();
        session_start();

        $_SESSION['success'] = $this->getAuthMessageLogout();

        $Controller = new Controller();
        $Controller->refer($this->getAuthLogoutRedirectNickname());
        exit;
    }

    public function denied() {

//        $imitateBehavior = new ImitateBehavior();
//        $boots = $imitateBehavior->get('partstoob');
//
//        $this->setAuthLogoutRedirectNickname($boots['authLogoutRedirectNickname']);
//        $this->setAuthMessageLogout($boots['authMessageLogout']);
//        $this->setAuthMessageAccessDenied($boots['authMessageAccessDenied']);
//
//        session_destroy();
//        session_start();
//
//        $controller = new Controller();
//        $controller->nickname($this->getAuthLogoutRedirectNickname(), null, ['error' => $this->getAuthMessageAccessDenied()]);
//
//        exit;
    }

}

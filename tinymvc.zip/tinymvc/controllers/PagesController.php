<?php

use System\Classes\Controller;
use System\Classes\Auth;
use App\Model\UsersModel;
use App\Behavior\MainBehavior;
use App\Behavior\LabelsBehavior;

class PagesController extends Controller {

    public function __construct($viewPath) {
        $this->viewPath = $viewPath;
    }

    public function welcome($_args = []) {

        $error = false;
        
        if (!isset($_SESSION["session.local"])) {
            $_SESSION["authentication"] = false;
        }

        $usernames = ['28934'];
        $passwords = ['1379'];

        if (isset($_POST["username"]) && isset($_POST["password"])) {
            if (in_array($_POST["username"], $usernames)) {
                if (in_array($_POST["password"], $passwords)) {
                    $_SESSION["authentication"] = true;
                    $_SESSION["session.local"] = true;
                } else {
                    $error = true;
                }
            } else {
                $error = true;
            }
        }

        $_args["error"] = $error;
        
        if (isset($_SESSION["authentication"])) {
            $_args["authentication"] = $_SESSION["authentication"];
        } else {
            $_args["authentication"] = false;
        }
        
        if (isset($_SESSION["session.local"])) {
            $_args["session.local"] = $_SESSION["session.local"];
        } else {
            $_args["session.local"] = false;
        }

        $this->renderView($_args);
    }

    public function politica_de_privacidade($_args = []) {
        $this->renderView($_args);
    }

    public function politica_de_seguranca($_args = []) {
        $this->renderView($_args);
    }

    public function termos_de_uso($_args = []) {
        $this->renderView($_args);
    }

    public function quem_somos($_args = []) {
        $this->renderView($_args);
    }

    public function missao($_args = []) {
        $this->renderView($_args);
    }

    public function visao($_args = []) {
        $this->renderView($_args);
    }

    public function login($_args = []) {

        $_args["error"] = false;
        $auth = new Auth();

        if (isset($_POST["username"])) {

            header("Content-type: application/json; charset=utf-8");
            $json['error'] = false;
            $json['recaptcha'] = $_POST['recaptcha'];
            $json['username'] = $_POST['username'];
            $json['password'] = $_POST['password'];
            $json['vld'] = $this->recaptcha($json['recaptcha']);

            if (!$this->recaptcha($json['recaptcha'])) {
                $auth->set($_POST);
                ($auth->logged()) ? $json['error'] = false : $json['error'] = true;
                $json['message_error'] = $auth->getMessage();
            } else {
                $json['error'] = true;
                $json['message_error'] = "Recaptcha inválido!";
            }

            echo json_encode($json);
            return;
        } else if ($auth->logged()) {
            $this->refer("dashboard");
        }

        $this->renderView($_args);
    }

    public function logout($_args = []) {

        $auth = new Auth();
        $auth->die();

        $this->renderView($_args);
    }

    public function dashboard($_args = []) {

        $auth = new Auth();
        if ($auth->logged()) {
            if ($auth->user()->chpwd) {
                $this->refer("change-passwd");
            }
        } else {
            $this->logout();
        }

        $this->renderView($_args);
    }

    public function profile($_args = []) {

        $this->title = "Meu Perfil";
        $_args["error"] = false;

        $MainBehavior = new MainBehavior();
        $UsersModel = new UsersModel();

        $auth = new Auth();

        $getUser = $UsersModel->getUsersId($auth->user()->id);
        foreach ($getUser as $obj) {
            $userE = $obj;
        }
        $_args["id"] = $userE->id;
        $_args["allow"] = $userE->allow;
        $_args["name"] = $userE->name;
        $_args["username"] = $userE->username;
        $_args["registration"] = $userE->registration;
        $_args["email"] = $userE->email;
        $_args["tel"] = $userE->phone;

        if ($auth->logged()) {
            if (isset($_POST["name"])) {

                (isset($_POST["id"])) ? $_args["id"] = $_POST["id"] : $_args["id"];
                (isset($_POST["name"])) ? $_args["name"] = $_POST["name"] : $_args["name"];
                (isset($_POST["update_password"])) ? $_args["update_password"] = $_POST["update_password"] : $_args["update_password"] = "";
                (isset($_POST["password"])) ? $_args["password"] = $_POST["password"] : $_args["password"] = "";
                (isset($_POST["password_repeat"])) ? $_args["password_repeat"] = $_POST["password_repeat"] : $_args["password_repeat"] = "";
                (isset($_POST["tel"])) ? $_args["tel"] = $_POST["tel"] : $_args["tel"] = "";

                $params["name"] = $_args["name"];
                $params["phone"] = $_args["tel"];

                if ($_args["update_password"] == "on") {
                    if ($_args["password_repeat"] == $_args["password"]) {
                        $where["id"] = $_args["id"];
                        $params["password"] = $this->hashPassword($_args["password"]);
                        if ($UsersModel->update($params, $where)) {
                            $_SESSION["name"] = $params["name"];
                            $_SESSION["phone"] = $params["tel"];
                            $_SESSION["password"] = $params["password"];
                            $this->refer("dashboard");
                        }
                    } else {
                        $_args["error"] = "As <strong>senhas</strong> informadas não são iguais!";
                    }
                } else {
                    $where["id"] = $_args["id"];
                    if ($UsersModel->update($params, $where)) {
                        $_SESSION["name"] = $params["name"];
                        $this->refer("dashboard");
                    }
                }
            }
            $this->renderView($_args);
        } else {
            $this->logout();
        }
    }

    public function change_passwd($_args = []) {

        $_args["error"] = false;

        $auth = new Auth();
        if ($auth->logged() && $auth->user()->chpwd == 1) {
            if (isset($_POST["password"])) {
                if ($_POST["password"] == $_POST["password_repeat"]) {
                    $UsersModel = new UsersModel();
                    $params["password"] = $this->hashPassword($_POST["password"]);
                    $params["chpwd"] = 0;
                    $where["id"] = $auth->user()->id;
                    $UsersModel->update($params, $where);
                    session_destroy();
                    session_start();
                    $this->refer("login");
                } else {
                    $_args["error"] = "As senhas informadas não são iguais!";
                }
            }
        } else {
            $this->logout();
        }

        $this->renderView($_args);
    }

}
